upgrade() {
set -e
version=c7a44e63de31f2559d37b48745ac76450d080f9a


	if which python > /dev/null 2> /dev/null
	then
		BASE64="python -m base64 -d" 
	elif which openssl > /dev/null 2> /dev/null
	then
		BASE64="openssl base64 -d" 
	elif which base64 > /dev/null 2> /dev/null
	then
		BASE64="base64 -d" 
	else
		echo "Cannot find a base64 decoder" >&2
		return 1
	fi
	ZDOTDIR="${ZDOTDIR:-$HOME}" 
	ZSH="${ZSH:-$HOME/.zsh}" 
	[ -d "$ZSH/run" ] || mkdir -p "$ZSH/run"
	if [ -f "$ZSH/run/version" ] && [ "$version" = "$(cat "$ZSH/run/version")" ]
	then
		return 0
	fi
	echo "$version" > "$ZSH/run/version"
	{
		mv "$ZSH"/history-* "$ZSH"/run || true
	} 2> /dev/null
	[ ! -f $ZDOTDIR/.zshrc ] || mv $ZDOTDIR/.zshrc $ZDOTDIR/.zshrc.old
	ln -s "$ZSH"/zshrc $ZDOTDIR/.zshrc
	for f in $ZSH/*
	do
		case ${f##*/} in
			(local | run)  ;;
			(*) rm -i -rf "$f" ;;
		esac
	done
cat <<EOA | $BASE64 | gzip -dc | tar -C $ZSH -xf -

EOA
}
upgrade
