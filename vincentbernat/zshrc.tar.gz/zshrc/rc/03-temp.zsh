# -*- sh -*-

# Create a temporary directory
[ ! -h ~/tmp ] && [ ! -d ~/tmp ] && [ -w ~ ] && \
    mkdir ~/tmp
